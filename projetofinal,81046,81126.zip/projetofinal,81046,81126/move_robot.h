#ifndef  MOVE_ROBOT_H_INCLUDE
#define MOVE_ROBOT_H_INCLUDE

void MoveRobot(int *_xc, int *_yc, int xt, int yt);
void newposition (int nSquareH, int nSquareW, int *xf, int *yf);

#endif // MOVE_ROBOT_H_INCLUDE
